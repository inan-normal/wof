module.exports = {
   prefix: "!",
  "token": "MTIzNjY2NTI5ODQ0NzQ5OTMxNg.GcPSJU.d6CQetXoUg5MkYH8b6eOJMLdDzfS6ZIRIAbfWw",
   owner: "797017129462792212",
}
