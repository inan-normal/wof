const {PermissionsBitField, EmbedBuilder, ButtonStyle, Client, GatewayIntentBits, ChannelType, Partials, ActionRowBuilder, SelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, SelectMenuInteraction, ButtonBuilder } = require("discord.js");
const config = require("./config.js");
const db = require("croxydb")
const Discord = require("discord.js")
const client = new Client({
  partials: [
    Partials.Message, // for message
    Partials.Channel, // for text channel
    Partials.GuildMember, // for guild member
    Partials.Reaction, // for message reaction
    Partials.GuildScheduledEvent, // for guild events
    Partials.User, // for discord user
    Partials.ThreadMember, // for thread member
  ],
  intents: [
    GatewayIntentBits.Guilds, // for guild related things
    GatewayIntentBits.GuildMembers, // for guild members related things
    GatewayIntentBits.GuildBans, // for manage guild bans
    GatewayIntentBits.GuildEmojisAndStickers, // for manage emojis and stickers
    GatewayIntentBits.GuildIntegrations, // for discord Integrations
    GatewayIntentBits.GuildWebhooks, // for discord webhooks
    GatewayIntentBits.GuildInvites, // for guild invite managing
    GatewayIntentBits.GuildVoiceStates, // for voice related things
    GatewayIntentBits.GuildPresences, // for user presence things
    GatewayIntentBits.GuildMessages, // for guild messages things
    GatewayIntentBits.GuildMessageReactions, // for message reactions things
    GatewayIntentBits.GuildMessageTyping, // for message typing things
    GatewayIntentBits.DirectMessages, // for dm messages
    GatewayIntentBits.DirectMessageReactions, // for dm message reaction
    GatewayIntentBits.DirectMessageTyping, // for dm message typinh
    GatewayIntentBits.MessageContent, // enable if you need message content things
  ],
});

module.exports = client;

require("./events/message.js")
require("./events/ready.js")

client.login(config.token)

client.on("guildMemberAdd", member => {
  const kanal = db.get(`hgbb_${member.guild.id}`)
const moment = require("moment");
const limit = new Map();
moment.locale("tr");
  if(!kanal) return;
  let kayıtsız = db.fetch(`kayıtsız_${member.guild.id}`)
        member.guild.members.cache.get(member.id).roles.add(kayıtsız)
  member.guild.channels.cache.get(kanal).send({content: `:inbox_tray: | Kullanıcı: ${member}\n\nSunucudaki Üye Sayısı: **${member.guild.memberCount}**\n\nHesap Oluşturulma Tarihi: \`${moment(member.createdAt).format('D MMMM YYYY')}\``})
})

client.on("guildMemberAdd", member => {
  const kanal = db.get(`gckanal_${member.guild.id}`)
  if(!kanal) return;
  member.guild.channels.cache.get(kanal).send({content: `:inbox_tray: | ${member} sunucuya katıldı! Sunucumuz **${member.guild.memberCount}** kişi oldu.`})
})

client.on("guildMemberRemove", member => {
  const kanal = db.get(`gckanal_${member.guild.id}`)
  if(!kanal) return;
  member.guild.channels.cache.get(kanal).send({content: `:outbox_tray: | ${member} sunucudan ayrıldı! Sunucumuz **${member.guild.memberCount}** kişi oldu.`})
})

client.on("guildMemberAdd", async(member) => {

const rol = db.fetch(`otorol_${member.guild.iḋ}`).rol

member.roles.add(rol)


});

client.on("messageCreate", (message) => {
  const db = require("croxydb")
  let everyone = db.fetch(`everyonehere_${message.guild.id}`)
  if (!everyone) return;

  if (everyone) {
    const everyone = [

      "@here",
      "@everyone",

    ]

    if (everyone.some(alo => message.content.toLowerCase().includes(alo))) {
      if (message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
      message.delete()
      message.channel.send(`<@${message.author.id}>, Lütfen Ever/Here Atma Lütfen!`)
    }
  }
})

client.on("messageCreate", (message) => {
  const db = require("croxydb")
  let kufur = db.fetch(`kufurengel_${message.guild.id}`)
  if (!kufur) return;

  if (kufur) {
    const kufurler = [
      
"Ağzını burnunu dağıtırım",
"oç", "amk", "ananı sikiyim", "ananıskm", "piç", "Amk", "amsk", "sikim", "sikiyim", "orospu çocuğu", "piç kurusu", "kahpe", "orospu", "sik", "yarrak", "amcık", "amık", "yarram", "sikimi ye", "mk", "mq", "aq", "amq",
      "Oruspu","Piç","Sg","sG","SG","Fuck",
        "siktir",
  "yarak kafası",
  "yark kafalı",
  "fuck",
  "puşt",
  "pust",
  "piç",
  "sikerim",
  "sik",
  "yarra",
  "yarrak",
  "amcık",
  "orospu",
  "orosbu",
  "orosbucocu",
  "oç",
  ".oc",
  "ibne",
  "yavşak",
  "bitch",
  "dalyarak",
  "amk",
  "awk",
  "taşak",
  "taşşak",
  "daşşak",
  "sikm",
  "sikim",
  "sikmm",
  "skim",
  "skm",
  "sg"
    ]

    if (kufurler.some(alo => message.content.toLowerCase().includes(alo))) {
      if (message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
      message.delete()
      message.channel.send(`<@${message.author.id}>, Bu Sunucuda Tüm Küfür Engelleme Açık Saygılı Ol `)
    }
  }
})

client.on("messageCreate", (message) => {
  const db = require("croxydb")
  let reklamlar = db.fetch(`reklamengel_${message.guild.id}`)
  if(!reklamlar) return;
  
  if(reklamlar) {

  const linkler = [
    "https://discord.gg",
    "Sunucum",
    "sunucum",
    "Sunucuma",
    "sunucuma",
    "www.youtube.com",
    "github.com/",
       
  ]

if(linkler.some(alo => message.content.toLowerCase().includes(alo))) {
if (message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
message.delete()
message.channel.send(`**Bu Sunucuda (Reklam Koruma) Aktif! <@${message.author.id}>** `)
}
}
})

client.on("messageCreate", (message) => {
  const db = require("croxydb")
  let J4J = db.fetch(`j4jengel_${message.guild.id}`)
  if(!J4J) return;
  
  if(J4J) {

  const linkler = [
    
    "j4J",
    "J4j",
    "J4J",
    "j4j"
       
  ]
  
if(linkler.some(alo => message.content.toLowerCase().includes(alo))) {
if (message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
message.delete()
message.channel.send(`**Bu Sunucuda (J4J YAZI KORUMA) Aktif! <@${message.author.id}>** `)
}
}
})

client.on("messageCreate", (message) => {
  const db = require("croxydb")
  let etiket = db.fetch(`etiketengelkomut_${message.guild.id}`)
  if(!etiket) return;
  
  if(etiket) {

  const etiketengel = [
    
    "@",
    "#"
       
  ]
  
if(etiketengel.some(alo => message.content.toLowerCase().includes(alo))) {
if (message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
message.delete()
  message.channel.send(`**Bu Sunucuda (Etiket Engel) Aktif! <@${message.author.id}>** `)
}
}
})

client.on("messageCreate", (message) => {
  const db = require("croxydb")
  let link = db.fetch(`linkengel_${message.guild.id}`)
  if(!link) return;
  
  if(link) {

  const linkler = [
    
    ".com.tr",
    ".net",
    ".org",
    ".tk",
    ".cf",
    ".gf",
    "https://",
    ".gq",
    "http://",
    ".com",
    ".gg",
    ".porn",
    ".edu",
    ".me"
       
  ]
  
if(linkler.some(alo => message.content.toLowerCase().includes(alo))) {
if (message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;
message.delete()
message.channel.send(`**Bu Sunucuda (Link Koruma) Aktif! <@${message.author.id}>** `)
}
}
})


client.on("messageCreate", (message) => {
  let saas = db.fetch(`saas_${message.guild.id}`);
  if (!saas) return;

  if (saas) {
    let selaamlar = message.content.toLowerCase();
    if (
      selaamlar === "sa" ||
      selaamlar === "Sa" ||
      selaamlar === "sA" ||
      selaamlar === "SA" ||
      selaamlar === "slm" ||
      selaamlar === "sea" ||
      selaamlar === "selamünaleyküm" ||
      selaamlar === "selamün Aleyküm" ||
      selaamlar === "Selamün Aleyküm" ||
      selaamlar === "selam"
    ) {
      message.channel.send(
        `<@${message.author.id}> Aleykümselam, Hoşgeldin`
      );
    }
  }
});

client.on('guildMemberAdd', async member => {
  let sayac = db.fetch(`sayac_${member.guild.id}`)
  let kalan = sayac.sayi - member.guild.memberCount || '?'
  if(!kalan) return;
  if(!sayac) return;
  
  client.channels.cache.get(sayac.kanal).send(":mega: Hoşgeldin **"+member.user.username+"** Seninle Beraber `"+member.guild.memberCount+"` Kişi Olduk, `"+sayac.sayi+"` Kişi Olmamıza Son `"+kalan+"` Kişi Kaldı! :mega:")
  
});
client.on('guildMemberRemove', async member => {
  
  let sayac = db.fetch(`sayac_${member.guild.id}`)
  let kalan = sayac.sayi - member.guild.memberCount
  if(!sayac) return;
  
  client.channels.cache.get(sayac.kanal).send(":mega: Görüşürüz **"+member.user.username+"** Senin Yüzünden `"+member.guild.memberCount+"` Kişi Olduk! :mega:")
  
});

client.on("messageCreate", async message => {
  
  const cmd = db.fetch(`cevap_${message.content}`)
  if(!cmd) return;
  
  if(cmd) {
    message.reply({ content: `${cmd.answer}` })
  }

});

//Uzun Komut Bölümü

