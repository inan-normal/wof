const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Ekonmi Menüsü!")
 .addFields({ name: '<a:acoolclap:1182291015596519466> cf', value: `Kumar Oynarsın!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> slot', value: `Kumar Oynarsın!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> çal', value: "Birinden Para Çalarsın!", inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> çalış', value: `Köle Gibi Çalışırsın!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> dilen', value: `Dilen Ve Para Kazan!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> günlük', value: `Günlük Harçlık Alırsın!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> banka-yatır', value: `Bankana Para Yatır!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> banka-çek', value: `Bankana Para Çek!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> para-ekle', value: `Birine Para Ekle`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> para-sil', value: `Birine Para Ekle`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> para-gönder', value: `Birine Para Gönderirsin!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> banka-sil', value: `Örnek (!bank-sil <@> miktar) !`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> cüzdan', value: `Kendi Parana Bakarsın!`, inline: true})
  .addFields({ name: '<a:acoolclap:1182291015596519466> yardım', value: `Yardım Menüsüne Bakarsın!`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> Prefix', value: `!`, inline: true})

  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'ekonomi'
}