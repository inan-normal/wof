const db = require("croxydb")

exports.run = async(client, message, args) => {
  let miktarsonuç = Math.floor(Math.random() * 99) + 1
    var sebep = ["Nft Satarak çalıştı","Emlakçı olarak çalıştı","Aşçı olarak çalıştı", "Mendil satıcısı olarak çalıştı","Sanayide çalıştı","Oto Yıkamacı çalıştı","Pythonic olarak çalıştı","Su satıcısı olarak çalıştı","Boş boş durdu"]
    var sebepsonuç = sebep[Math.floor(Math.random() * sebep.length)];
    db.add(`param_${message.author.id}`, miktarsonuç)
    return message.channel.send(`${message.author} ${sebepsonuç} ve **${miktarsonuç}** TL kazandı!`)
};
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ["çalış","Çalış","ÇALIŞ"],
    permLevel: 0
  };
  
  exports.help = {
    name: 'çalış' 
  }