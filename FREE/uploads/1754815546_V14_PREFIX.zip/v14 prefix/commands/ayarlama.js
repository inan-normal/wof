const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Ayarlama Menüsü!")
    .addFields({ name: '<a:astaff:1190777351752130721> oto-cevap', value: `Oto Cevabı Silemesin!`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> hgbb-aç', value: `Hoş Geldin Bay Bay Kanalı Ayarla`, inline: true})
   .addFields({ name: '<a:astaff:1190777351752130721> sayaç', value: `Hedef Gibi Kullanıyor`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> saas', value: `Biri Sa Selam Falan Falan Yazdığı Zaman Botumuz Otomatik Cevap Verir`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> otorol', value: `Otomatik Rol Ver`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> öneri-log', value: `Biri !öneri-ver Komutu Kullandı Zaman Log Kanalına Mesaj Atması`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721>  Prefix', value: `!`, inline: true})

  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'ayarlama'
};

