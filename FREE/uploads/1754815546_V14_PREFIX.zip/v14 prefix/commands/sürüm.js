const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Güncelleme 12.05.2024")
  .addFields({ name:  'Botun Kendi Sürümü', value: `Yeni`, inline: true})
  .addFields({ name:  'Kullandı Sürümü Nodejs/Dc.js', value: `!botbilgi`, inline: true})
  .addFields({ name:  'Sitemizin Sürümü', value: `Baya Eski`, inline: true})
  .addFields({ name:  'Komutlar Güncelleme', value: `
!güvenlik==> Sunucunuzu Güvenli Yapıyor `, inline: true})
  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'sürüm'
};