const {EmbedBuilder} = require("discord.js");
const Discord = require('discord.js')

exports.run = async (client, message, args) => {
 if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return message.reply(`   **Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.**`);
    var rol = message.mentions.roles.first()
    if(!rol) message.reply("Lütfen bir rol belirt.")
    message.guild.members.cache.forEach(arez => arez.roles.add(rol.id))
    return message.reply(`**Komut Çalışıyor Biraz Zaman Alıyor**`)

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "herkeserolver"
};

