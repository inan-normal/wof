const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Yetkil Menüsü!")
   .addFields({ name: '<a:astaff:1190777351752130721> herkeserolver', value: `Yeni Sunucu İçin En İyi Komut!`, inline: true})
   .addFields({ name: '<a:astaff:1190777351752130721> herkestenrolal', value: `Yeni Sunucu İçin En İyi Komut!`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> sil', value: `Mesaj Sil`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> ban', value: `Ban At`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721>  kick', value: `Birini Sunucudan At`, inline: true})
    .addFields({ name: '<a:astaff:1190777351752130721>  rol-kur', value: `Rol OLuştur`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721>  güvenlik', value: `Küfür Engel Falan Hepsi Olda!`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721>  Prefix', value: `!`, inline: true})

  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'yetkil'
};