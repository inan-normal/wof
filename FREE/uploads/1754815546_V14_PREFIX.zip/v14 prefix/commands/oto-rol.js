const {EmbedBuilder} = require("discord.js");
const { prefix } = require("../config.js")
const db = require('croxydb')
const Discord = require("discord.js")

exports.run = async (client, message, args) => {

  
  if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return message.reply(`   **Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.**`);
    
   const member = message.mentions.roles.first();
  
   if(!member) return message.reply("Rol Belırtın.")

  
  message.reply("Ayarlandı")
  db.set(`otorol_${message.guild.iḋ}`, { rol: member.id })
  
};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "otorol"
};