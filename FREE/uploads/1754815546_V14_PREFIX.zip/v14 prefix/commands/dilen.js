const db = require("croxydb")

exports.run = async(client, message, args) => {
  let miktarsonuç = Math.floor(Math.random() * 40) + 1
    db.add(`param_${message.author.id}`, miktarsonuç)
    return message.channel.send(`${message.author} Dilendiniz ve **${miktarsonuç}** TL kazandı!`)
};
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
  };
  
  exports.help = {
    name: 'dilen' 
  }