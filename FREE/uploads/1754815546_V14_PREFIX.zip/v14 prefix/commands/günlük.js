const slenzydb = require('croxydb');
const ms = require('ms')
const moment = require("moment");
exports.run = async (client, message, args) => {
  
 var paralar = ['25000','50000'];
      var param = paralar[Math.floor(Math.random() * paralar.length)];
      slenzydb.add(`param_${message.author.id}`, param)
message.channel.send(`${param} Kadar Parayı Kaptın!`);
       slenzydb.set(`günlük_${message.author.id}`, Date.now());
    let yavaşmod = 8.64e+7, 

        amount = Math.floor(Math.random() * 1000) + 4000;      
    if (lastDaily !== null && yavaşmod - (Date.now() - lastDaily) > 0) {

        let timeObj = ms(yavaşmod - (Date.now() - lastDaily));




      
      return message.reply(`Sadece 24 saatte bir günlük para alabilirsin!`)

      

    } else {

    }
}

  


exports.conf = {
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'günlük'
};