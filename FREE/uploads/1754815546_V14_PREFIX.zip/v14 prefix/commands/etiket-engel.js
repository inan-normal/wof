const Discord = require("discord.js")
const db = require("croxydb")


module.exports.run = async (client, message, args) => {

  
    if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return message.reply(`❌   **Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.**`);


let ETİKET = db.fetch(`etiketengelkomut_${message.guild.id}`);
   const embed = new Discord.EmbedBuilder()
   .setColor("#ff0000")
   .setDescription("✅ **ETİKET Engel Sistem Aktif Edildi**")
   const embed2 = new Discord.EmbedBuilder()
   .setColor("#ff0000")
   .setDescription("✅ **ETİKET Engel Sistemi Kapatıldı**")
if (ETİKET)  {

    db.delete(`etiketengelkomut_${message.guild.id}`);
    message.channel.send({embeds: [embed2], allowedMentions: { repliedUser: false }})

    return
}

if (!ETİKET)  {

    db.set(`etiketengelkomut_${message.guild.id}`, true);
    message.channel.send({embeds: [embed], allowedMentions: { repliedUser: false }})

    return
}



},
  
  exports.conf = {
   
    aliases: []
    
  }
  
exports.help = {
name: "etiket-engel",

usage: "",
}