const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Yetkil Menüsü!")
  .addFields({ name: '<a:astaff:1190777351752130721> etiket-engel', value: `Etiket  Engel Komutu (@,#)`, inline: true})
     .addFields({ name: '<a:astaff:1190777351752130721> link-engel', value: `Link Engel Komutu  (Fazla)`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> ever-here-engel', value: `Ever Here Engel Komutu (@everyone,@here)`, inline: true})
      .addFields({ name: '<a:astaff:1190777351752130721> j4j-engel', value: `J4J Yazı Engelle (j4j,J4J,J4j,j4J)`, inline: true})
      .addFields({ name: '<a:astaff:1190777351752130721> reklam-engel', value:  `Reklam Engel Komutu (FAZLA)`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721> küfür-engel', value: `Küfür Engel Komutu (AZ)`, inline: true})
  .addFields({ name: '<a:astaff:1190777351752130721>  Prefix', value: `!`, inline: true})

  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'güvenlik'
};