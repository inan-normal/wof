const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Yardım Komutları ")
  
  .addFields({ name:  '<a:astaff:1190777351752130721> yetkil', value: `Yetkili Komutları Gösterir`, inline: true})
  
    .addFields({ name:  '<a:astaff:1190777351752130721> güvenlik', value: `Güvenlik Komutlarını Gösterir Tavsiye Ediyoruz`, inline: true})
  
   .addFields({ name:  '<a:astaff:1190777351752130721> ayarlama', value: `Ayarlama Komutları Gösterir`, inline: true})
  
  .addFields({ name:  '<a:ayarlar:1182041028786671657> botkod', value: `Botun Komutları Gösterir`, inline: true})
  
  .addFields({ name:  '<:user:1191060660906377348> üye', value: `Kullanıcı/Eğlence Komutları Gösterir`, inline: true})
  
  .addFields({ name:  '<a:acoolclap:1182291015596519466> ekonomi', value: `Ekonomi Komutları Gösterir`, inline: true})
  
  .addFields({ name:  '🤖 !sürüm', value: `Sürüme Bak `, inline: true})
  .addFields({ name:  'Linkler Prefix', value: `
  [<:openwrt2:1191060139277553748> **Davet Et Beni** ](https://discord.com/oauth2/authorize?client_id=1236665298447499316)
  [<:openwrt2:1191060139277553748> **Sitemiz** ](https://inquisitive-wise-ulna.glitch.me/)
  [<:openwrt2:1191060139277553748> **Uptime** ](https://discord.gg/vvf3kcSx)
  [<:openwrt2:1191060139277553748> **OY VER**](https://top.gg/bot/1236665298447499316/vote)

  `, inline: true})
  
  .addFields({ name:  '<a:aDonenDunya:1182302343518244955> Prefix', value: `!`, inline: true})
  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'yardım'
};