const Discord = require('discord.js')
const db = require('croxydb');
const ms = require('ms')
const moment = require("moment");
exports.run = async (client, message, args) => {
    let user = message.author || message.mentions.users.first()
    let kullanıcı = user.id
let banka = db.fetch(`banka_${kullanıcı}`)
let param = db.fetch(`param_${kullanıcı}`)
let altın = db.fetch(`altın_${kullanıcı}`)
let elmas = db.fetch(`elmas_${kullanıcı}`)
const embed = new Discord.EmbedBuilder()
.setTitle("Cüzdan Menüsü!")
.addFields({ name: '💵 Para', value: ` ${param || "Paran Yok!- !günlük"}`, inline: true})
.addFields({ name: '🏦 Banka', value: `${banka || "Bankada Paran !banka-yatır"}`, inline: true})
.setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}

  


exports.conf = {
  aliases: ["cüzdan"],
  permLevel: 0
};

exports.help = {
  name: 'param'
};