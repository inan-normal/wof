const db = require("croxydb")
const ms = require("ms")
exports.run = async(client, message, args) => {
 let kullanıcı = message.mentions.users.first()
 if (!kullanıcı) return message.reply("Lütfen bir kullanıcı etiketle!")
 let param = db.fetch(`param_${kullanıcı.id}`)
 if (!param) return message.reply("Kullanıcının parası yok ")
  let miktarsonuç = Math.floor(Math.random() * 5) + 10
    db.add(`param_${message.author.id}`, miktarsonuç)
    db.add(`param_${kullanıcı.id}`, -miktarsonuç)
    db.set(`cal_${message.author.id}`, Date.now());

    message.channel.send(`${message.author} <@${kullanıcı.id}> Kullanıcısından **${miktarsonuç}** TL çaldı!`)
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ["çal","Çal","ÇAL"],
    permLevel: 0
  };
  
  exports.help = {
    name: 'çal' 
  }
