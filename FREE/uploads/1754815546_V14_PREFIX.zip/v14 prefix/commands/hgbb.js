const {EmbedBuilder} = require("discord.js");
const Discord = require("discord.js")
const db = require("croxydb")
exports.run = (client, message, args) => {
const kanal = message.mentions.channels.first()
if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return message.reply(`   **Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.**`);
if(!kanal) return message.reply({content: "Bir kanal etiketlemelisin."})
db.set(`gckanal_${message.guild.id}`, kanal.id)
message.reply({content: `Giriş çıkış kanalı ${kanal} olarak ayarlandı`})
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
}

exports.help = {
  name: 'hgbb-aç'
};