const db = require("croxydb")

exports.run = async(client, message, args) => {
  let miktarsonuç = Math.floor(Math.random() * 100) + 1
    var sebep = ["1","2","3","4","5","6"]
    var sebepsonuç = sebep[Math.floor(Math.random() * sebep.length)];
    db.add(`para_${message.author.id}`, miktarsonuç)
    return message.channel.send(`${message.author})= ${sebepsonuç} Zar Attın Ve  **${miktarsonuç}** TL Kazandın`)
};
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
  };
  
  exports.help = {
    name: 'zarat' 
  }