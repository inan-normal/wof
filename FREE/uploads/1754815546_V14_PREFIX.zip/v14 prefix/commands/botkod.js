const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Bot Kod Menüsü!")
  .addFields({ name: '<a:ayarlar:1182041028786671657> botbilgi', value: `Bota Ait Bilgisini Atıyor`, inline: true})
  .addFields({ name: '<a:ayarlar:1182041028786671657> ping', value: `Botun Pingisi Atıyor`, inline: true})
  .addFields({ name: '<a:ayarlar:1182041028786671657> yardım', value: `Yardım Menüsüne Bakarsın!`, inline: true})
  .addFields({ name: '<a:ayarlar:1182041028786671657> Prefix', value: `!`, inline: true})

  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'botkod'
}