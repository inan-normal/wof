const {EmbedBuilder} = require("discord.js");
const Discord = require('discord.js')

exports.run = async (client, message, args) => {
 if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return message.reply(`   **Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.**`);
    var rol = message.mentions.roles.first()
    if(!rol) message.reply("Lütfen bir rol belirt.")
    message.guild.members.cache.forEach(arez => arez.roles.remove(rol.id))
    return message.reply(`**Bu İşlem Uzun Sürüyor!**`)

};
exports.conf = {
  aliases: ["herkesten-rolal","Herkestenrolal","HERKESTENROLAL"]
};

exports.help = {
  name: "herkestenrolal"
};