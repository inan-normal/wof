const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("GELECEK KOD DAN HABERİN OLSUN")
  .addFields({ name:  'Gelecek Kod==>', value: `!premıum-ver-al`, inline: true})
  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'gelecek-kod'
};