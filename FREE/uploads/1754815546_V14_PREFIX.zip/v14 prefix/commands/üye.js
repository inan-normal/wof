const Discord = require('discord.js')
const db = require('croxydb');


exports.run = async (client, message, args) => {
  
  const embed = new Discord.EmbedBuilder()
  .setTitle("Üye Menüsü!")
  .addFields({ name: '<:user:1191060660906377348> sarıl', value: `Kankana Sarıl
  +`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> emojiyaz', value: `Emoji Yazı Yaz`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> avatar', value: `Profil Resim`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> swemoji', value: `Sunucunun Emojını Atıyor`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> sunucubilgi', value: "Sunucunun Bilgisi Atıyor", inline: true})
  .addFields({ name: '<:user:1191060660906377348> say', value: `Sunucunun Üye/Bot/YanHesap (Yan Hesap Çalışmıyor)`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> kullanıcıbilgi', value: `İstediniz Kişinin Bilgisi Atıyor`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> öneri-ver', value: `Öneri Verisiniz (Sunucu İçin)`, inline: true})
    .addFields({ name: '<:user:1191060660906377348> kaç-cm', value: `Kaç Cm Senin`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> yardım', value: `Yardım Menüsüne Bakarsın!`, inline: true})
  .addFields({ name: '<:user:1191060660906377348> Prefix', value: `!`, inline: true})

  .setColor("#ff0000")
  message.channel.send({embeds: [embed]})
}
exports.conf = {
  
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'üye'
}