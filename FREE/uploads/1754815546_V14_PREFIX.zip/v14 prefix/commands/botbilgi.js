const {
  Discord,
  MessageEmbed,
  Permissions,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  EmbedBuilder,
  Colors,
  version,
} = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
exports.run = async (client, message, args) => {
  const Uptime = moment
    .duration(client.uptime)
    .format(" D [gün], H [saat], m [dakika], s [saniye]");
  const embed = new EmbedBuilder()
    .setAuthor({
      name: "Bot İstatistik",
      iconURL: client.user.avatarURL(),
    })
    .setDescription(
      `
  
  <a:ahile:1182302400925667358> Toplam Kullanıcı: **${client.users.cache.size}**
  <a:ahile:1182302400925667358> Toplam Sunucu: **${client.guilds.cache.size}**
  <a:ahile:1182302400925667358> Toplam Kanal: **${client.channels.cache.size}**
  
  <a:ahile:1182302400925667358> Hafıza Kullanımı: **${(
    process.memoryUsage().heapUsed /
    1024 /
    512
  ).toFixed(2)}Mb**
  <a:ahile:1182302400925667358> Uptime: **${Uptime}**
  
  <a:ahile:1182302400925667358> NodeJS Sürümü: **${process.version}**
  <a:ahile:1182302400925667358> DiscordJS Sürümü: **${version}**`
    )
    .setFooter({
      text: `Bot İstatistik`,
      iconURL: message.member.displayAvatarURL({ dynamic: true }),
    })
    .setColor(Colors.Blurple);
  message.reply({ embeds: [embed] });
};
exports.conf = {
  aliases: ["botbilgi"]
};
exports.help = {
  name: "istatistik",
};
