const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  const random = Math.floor(Math.random() * 40) + 1
  
  message.channel.send(`Masallah  **${random}cm** :flushed:`)
}

  exports.conf = {
  aliases: ["kaçcm"]
};

exports.help = {
  name: "kaç-cm"
};