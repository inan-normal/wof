const Discord = require("discord.js")
const db = require("croxydb")


module.exports.run = async (client, message, args) => {

  
    if (!message.member.permissions.has(Discord.PermissionsBitField.Flags.Administrator)) return message.reply(`❌   **Bu komutu kullanabilmek için "\`Yönetici\`" yetkisine sahip olmalısın.**`);


let reklam = db.fetch(`j4jengel_${message.guild.id}`);
   const embed = new Discord.EmbedBuilder()
   .setColor("#ff0000")
   .setDescription("✅ **J4J Engel Sistem Aktif Edildi**")
   const embed2 = new Discord.EmbedBuilder()
   .setColor("#ff0000")
   .setDescription("✅ **J4J Engel Sistemi Kapatıldı**")
if (reklam)  {

    db.delete(`j4jengel_${message.guild.id}`);
    message.channel.send({embeds: [embed2], allowedMentions: { repliedUser: false }})

    return
}

if (!reklam)  {

    db.set(`j4jengel_${message.guild.id}`, true);
    message.channel.send({embeds: [embed], allowedMentions: { repliedUser: false }})

    return
}



},
  
  exports.conf = {
   
    aliases: []
    
  }
  
exports.help = {
name: "j4j-engel",

usage: "",
}