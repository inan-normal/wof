const kurucuRolRenk = '#ffff00';
const adminRolRenk = '#ff0000';
const üyeRolRenk = '#0020ff';
const botRolRenk = '#00b1ff';

module.exports = [{
  name: "kanal-sil",
  code: `Kanal silindi
    $deleteChannel[$mentionedChannels[1]]$onlyPerms[managemessages;bu komutu kullanmasın]
  $onlyPerms[banmembers;**Yetkin yok!**]
  `

}, {
  name: "kanal-kilitle",
  code: `
  **Kanal Başarılı şekilde kilitlendi **$modifyChannelPerms[$channelID;$guildID;-sendmessages;+addreactions]
     $onlyPerms[banmembers;**Yetkin yok!**]
    `
}, {
  name: "kanal-aç",
  code: `
  **Kanal Başarılı Şekilde açıldı**$modifyChannelPerms[$channelID;$guildID;+sendmessages;+addreactions]
     $onlyPerms[banmembers;**Yetkin yok!**]
     `
}, {
  name: "kanal-kur",
  code: `
  Yazı kanalı kurdu 
  $createChannel[$guildID;1 Yazı kanal;Text;false]
  $onlyPerms[managemessages;bu komutu kullanmasın]
  $onlyPerms[banmembers;**Yetkin yok!**]
  `
}, {
  name: "ses-kanal-kur",
  code: `
  Kurudu adı kanal 1
  $createChannel[$guildID;1 Sesli kanal ;Voice;false]
  $onlyPerms[managemessages;bu komutu kullanmasın]
  $onlyPerms[banmembers;**Yetkin yok!**]
  $onlyIf[$getGlobalUserVar[karaliste]!=alınmış;Karalistedesin]`

}, {
  name: "kategor-kur",
  code: `
  Kurudu adı Kategor 1
  $createChannel[$guildID;1 Kategor;Category;false]
  $onlyPerms[managemessages;bu komutu kullanmasın]
  $onlyPerms[banmembers;**Yetkin yok!**]
  `

}, {
  name: "sunucukur",

  code: `
  $setGuildVar[linkengel;açık]
  $setGuildVar[saas;açık]
$channelSendMessage[$get[kural];{newEmbed:{author:$memberDisplayName[$guildID;$guildOwnerID]:$userAvatar[$guildOwnerID]}{title:Sunucu kuruldu}{description:!kural Yaz Hadi Bir Topluluk Sunucu İçin : )}]

$channelSendMessage[$get[hgbb];{newEmbed:{author:$memberDisplayName[$guildID;$guildOwnerID]:$userAvatar[$guildOwnerID]}{title:Sunucu kuruldu}{description:Bazı Botları Ekle Ve HgBb Yap Hadi Ne Duruyor Sun: )}]

$channelSendMessage[$get[sohbetKanalı];{newEmbed:{author:$memberDisplayName[$guildID;$guildOwnerID]:$userAvatar[$guildOwnerID]}{title:Sunucu kuruldu}{description:Sunucu kurulma işlemi başarılı bir şekilde tamamlandı. koruma hepsi açıldı link koruması açık ÖNEMLİ kategor kilitlendi ve rolere admin hariç tüm gereken izinle verildi ve saas komutları açıldı Rica ederim hazır sunucu : )}]

$createRole[$guildID;🤖 Bot;${botRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;👤 Üye;${üyeRolRenk};1;;true;;false;false;Rol oluşturuldu!;]
$createRole[$guildID;⚙️ Admin;${adminRolRenk};1;;true;;true;false;Rol oluşturuldu!;]
$createRole[$guildID;🎩 Yetkili;${adminRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;🎩 Üst Yetkili;${adminRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;👑 Kurucu;${kurucuRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;👑 Has Kurucu;${kurucuRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]

$modifyChannelPerms[$get[2];$guildID;-sendmessages]

$modifyChannelPerms[$get[1];$guildID;-sendmessages]

  $createChannel[$guildID;╰┈➤《🎮》YILDIRIM Bahis;Text;false;$get[4]]
  $createChannel[$guildID;├┈➤《🎮》╭┈➤ OWO Bahis;Text;false;$get[4]]

$let[sohbetKanalı;$createChannel[$guildID;╭┈➤《💭》sohbet;Text;true;$get[3]]]

$createChannel[$guildID;╰┈➤《💻》öNERİ LOG;Text;false;$get[2]]
$createChannel[$guildID;├┈➤《🎭》çekiliş;Text;false;$get[2]]
$createChannel[$guildID;├┈➤《📢》duyuru;Text;false;$get[2]]
$let[kural;$createChannel[$guildID;╭┈➤《📕》kurallar;Text;true;$get[2]]]

$let[hgbb;$createChannel[$guildID;╭┈➤《🙋》gelen-giden;Text;true;$get[1]]]
$createChannel[$guildID;╰┈➤《💻》otorol;Text;false;$get[1]]

$let[4;$createChannel[$guildID;∆ OYUN ODALARI;Category;true]]
$let[3;$createChannel[$guildID;∆ GENEL ODALAR;Category;true]]
$let[2;$createChannel[$guildID;∆ ÖNEMLİ;Category;true]]
$let[1;$createChannel[$guildID;∆ HOŞGELDİN;Category;true]]

$deleteRoles[$joinSplitText[;]]$textSplit[$guildRoles[$guildID;id;,];,]
$deleteChannels[$joinSplitText[;]]$textSplit[$guildChannels[$guildID;id;,];,]
$onlyClientPerms[managechannels;Bu işlemi gerçekleştirmem için Kanalları Yönet iznim olması gerekiyor.]
+eval $onlyIf[$rolePosition[$userHighestRole[$clientID;$guildID]]<=$rolePosition[$guildHighestRole];Lütfen benim rolümu en üste taşı yoksa rol silemem hepsini]
$onlyForIDs[$guildOwnerID;Bu komutu sadece sunucu sahibi kullanabilir!]
`
}, {

  name: "yaz",
  code: `$deletecommand **$message**
   $onlyPerms[managemessages;Bu kod yetkili kod oldu!]
`
}, {

  name: "ban",

  code: `
  $ban[$guildID;$mentioned[1];0]
  $onlyPerms[banmembers;Yasaklama izinlerine ihtiyacınız var!]
  $suppressErrors[Bir Hata Oluştu kullanıcı ban atamadım.]
  $description[**Başarıyla yasaklandı**

  **Yasaklanan Kişi:** <@$mentioned[1]>

  **Yasaklanan Kişi ID:** $mentioned[1],

  **Yasaklayan Yetkili:** <@$authorID>]
  $color[Red]
  $onlyIf[$mentioned[1]!=$authorID;Kendini yasaklayamazsın]
  $onlyIf[$mentioned[1]!=1178404693685325845;Kendime ban atamam]
  $suppressErrors[Hata]
   $onlyPerms[banmembers;Yasaklama izinlerine ihtiyacınız var!]
   $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`

}, {
  name: "unban",

  code: `$unban[$guildID;$mentioned[1]]
    $description[**__$mentioned[1] Banı başarılı kalktı__**]
  $suppressErrors[Hata]
  $onlyIf[$authorID!=$mentioned[1]; Kendini etiketleme]
  $onlyPerms[banmembers;Yasaklama izinlerine ihtiyacınız var!]
  `
}, {
  name: "sil",
  code:
    `
  $clear[$channelID;$message[1]]
  $onlyIf[$message[1]<=500;Sayı 500 den küçük veya ona eşit olmalıdır]
  $onlyIf[$message[1]>=5;Minimum 5!]

$onlyPerms[managemessages;Yetkin yok]
`

}, {
  name: "yavaşmod",
  code:
    `
  $slowmode[$noMentionMessages;$channelID]

  $sendMessage[Yavaş mod \`$noMentionMessage\` saniye olarak ayarladım.;false]

  $onlyIf[$noMentionMessage!=; Zaman belirtilmedi. Örnek: !yavaşmod 1]
  $onlyClientPerms[managechannels;**Yetkim yok.**]
$onlyIf[$message[1]<=21600;Sayı  21600 den küçük veya ona eşit olmalıdır]
 $onlyPerms[managemessages;Yetkin yok]



  `
},{
  name: "rol-kur",
  code: `
$description[**__Rol Kurdum__

Rol kurdu kişi:<@$authorID>

Rol İsim:$message**]
$createRole[$guildID;$message;$random[1;999999];;;;;false;;]
$onlyPerms[banmembers;Yetki izini gerekiyor]
$suppressErrors[Bir hata oluştu ?]`

  },{
  name: "randomçekiliş",
  code: `
  $description[**__Çekiliş Başladı__
 
  🎉 Baslatan kişi:<@$authorID>

  🏷️ Ödül:$message[2] $message[3] $message[4] $message[5]

  ⌛Süre:$replaceText[$replaceText[$replaceText[$message[1];s;:saniye];m;:dakika];h;:saat]**]
  
  $editIn[$message[1];
  {newEmbed:
  {description:
  **__Çekiliş Bitti__**

  **<a:akral:1182291790431277056> Baslatan kişi:<@$authorID>**
  
  **🎉 Kazanan Kişi:<@$randomUserID>**

  **🏷️ Ödül:**$message[2] $message[3] $message[4] $message[5]


  $onlyPerms[banmembers;Yetki izini gerekiyor]
  $suppressErrors[Bir hata oluştu]
  $onlyIf[$message[2]!=;Bir ödü gir]
  $onlyIf[$message[1]!=;Bir süre gir]


  $onlyPerms[banmembers;Yetki izini gerekiyor]`

    },{
  name: "rol-sil",
    code: `
    $description[**__Rol Silindi__**

    Silinen rol:<@&$mentionedRoles[1]>

    Rol Silen Yönetici:<@$authorID>

    $deleteRoles[$guildID;$mentionedRoles[1]]
    $onlyPerms[banmembers;Yetki izini gerekiyor]
    $onlyIf[$mentionedRolesCount==1;Bir rol etiketle]`
},{
  name:"zamanaşımı",
    code:`

  $timeoutMember[$guildID;$mentioned[1];$noMentionMessage[1];false;$filterMessage[$noMentionMessage;$noMentionMessage[1]]]

  $title[1;Timeout]

  $description[1;<@$mentioned[1]> adlı kullanıcı <@$authorID> tarafından Zaman Aşımı Uygulandı!]

  $onlyIf[$message[2]!=;**Zaman belirtilmedi. Örnek: !zamanaşımı 

  1s saniye

  1 dakika

  1h saat 

  Gün Ve Ay hata verilebilir**]

  $onlyIf[$message[1]!=;**Kullanıcı belirtilmedi.**]

  $onlyIf[$message[1]<=500350;Sayı 50035 den küçük veya ona eşit olmalıdır veya s h m gibi şeyleri kullanın]

  $onlyClientPerms[managechannels;**Yetkim yok.**]

  $onlyPerms[managemessages;Yetkin yok]


  `},{
   name:"oylama",
    code:`
  $title[OYLAMA BASLADI]
  $description[**Oylama** **__Başladı__**

  **Oylama Başlatan: <@$authorID>

  Oylama Konusu: $message**]
  $addClientReactions[❌;✅]
$onlyClientPerms[managechannels;**Yetkim yok.**]

$onlyPerms[managemessages;Yetkin yok]
  `
    },{
    name: "kural",
    code: `
      $description[**Kurallar
  
  <a:ago:1182277758408212540> ! Küfür etmek yasak
  
  <a:ago:1182277758408212540> ! Reklam yasak 
  
  <a:ago:1182277758408212540> ! +18 Foto veya link atmak ve konuşma yasak 
  
  <a:ago:1182277758408212540>  ! Caps Yazmak yasak # de geçerlidir
  
  <a:ago:1182277758408212540>  ! Her türlü dine sövmek yasak
  
  <a:ago:1182277758408212540> ! Kızlara Rahatsızlık vermek yasak ve erkekleri de
  
  <a:ago:1182277758408212540> ! Kurucu ya baskı ve Küfür ve Bağırmak yasak 
  
  <a:ago:1182277758408212540> ! Kanalı amaçsız kullanmak yasak
  
  <a:ago:1182277758408212540> ! lütfen Kuralları Uyun 3 de ban yersiniz 
  
  <a:ago:1182277758408212540> ! Reklam affetmiyoruz
  
  <a:verified:1182041026790174720> Onay almıştı onay alınan kişi <@1141265487330811944>
  
  $color[#ff0000] **]
  $onlyPerms[managemessages;Yetkin yok]`}]
  