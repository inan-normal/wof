module.exports = [{
  name: "yardım",
  aliases: [
    "Yardım",
    "YaRdIm",
    "YARDIM",],
  code: `
  $description[**Legendary Wolf Yardım**
**<a:akral:1182291790431277056>|**\`!sahipkod\`**|Bot sahibi kodları gösteri**

**<a:havalidans:1182041022763642880>|**\`!eğlence\`**|Eğlence kodları gösteriyor**

**<:user:1191060660906377348>|**\`!üye\`**|Üye kodları gösteriyor**

**<a:60saniye:1182041034130198618>|**\`!saat\`**|Saat kodları gösteriyor**

**<a:hypesquad:1182040996616339599>|**\`!yetkili\`**|Yetkili Kodları gösteriyor**

**<a:hypesquad:1182040996616339599>|**\`!ayarlama\`**|Ayarlama kodları gösterir**

**<a:astaff:1190777351752130721>|**\`!botkodlar\`|**Botun kodları gösteriyor**

**<:openwrt2:1191060139277553748>|\`!linkle\`|Linklere bakarsınız**

**<:iconscomments:1190777879961804850>|\`!ekbilgi\`|Ek bilgi verir lazım olan her şey**
**[<:discord_gibirnet:1190779352636465153> Siteden]( https://58e596f9-96d3-487a-be4a-fd0cd52a45cd-00-3pwi5txi3kboh.pike.replit.dev/ )**
$thumbnail[$userAvatar[$authorID]]]$thumbnail[$userAvatar[$authorID]
  
  $color[#ff0000]
  
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
}, {
  name: "yetkili",
  aliases: [
    "yetkili",
    "Yetkili",
  ],
  code: `
  $title[Yetkili Menüsü]

  $description[\`!sil\`
**<a:ayarlar:1182041028786671657> Max 500**

\`!yavaşmod\`
**<a:ayarlar:1182041028786671657> Kanalın Yavaş mod ayarla**
   
  \`!kanal-sil\` 
**<a:ayarlar:1182041028786671657> Kanal sile Uyarı ele bir kanal etiketlemeseniz oldunuz kanalı sile!**

  \`!kanal-kilitle\`
**<a:ayarlar:1182041028786671657> Oldunuz kanalı kilitle **
  
  \`!yaz\`
**<a:ayarlar:1182041028786671657> Bota mesaj yazdırır**
  
 \`!kanal-aç\`
 **<a:ayarlar:1182041028786671657> Kanal açıldı**

  \`!rol-sil\`
**<a:ayarlar:1182041028786671657> Rol sile **

  \`!allroldelete\`
**<a:ayarlar:1182041028786671657> Rol sile Hepsini (owner!)**

  \`!rol-kur\`
**<a:ayarlar:1182041028786671657> Rol kur **
  
  \`!kanal-kur\`
**<a:ayarlar:1182041028786671657> Yazı kanal kur**

  \`!ses-kanal-kur\`
**<a:ayarlar:1182041028786671657> Ses kanal kur**

  \`!kategor-kur\` 
**<a:ayarlar:1182041028786671657> Kategor kur**

  \`!ban\`
**<a:ayarlar:1182041028786671657> Ban atasın**

  \`!unban\`
**<a:ayarlar:1182041028786671657>Ban kaldı**

 \`!sunucukur\`
**<a:ayarlar:1182041028786671657> Sunucu kuruyor**

  \`!zamanaşımı\`
**<a:ayarlar:1182041028786671657> Birini zaman aşımına sok**

  \`!oylama\`
  **<a:ayarlar:1182041028786671657> Oylama yap**
  
  \`!randomçekiliş\`
**<a:ayarlar:1182041028786671657> Random çekiliş yapar 
<a:ayarlar:1182041028786671657> s=saniye
<a:ayarlar:1182041028786671657> m=dakika
<a:ayarlar:1182041028786671657> h=saat**
 
  \`!kural\`
**<a:ayarlar:1182041028786671657> Kurallar ata üyede kullanabilir**
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]$color[#ff0000]`
}, {
  name: "kural",
  code: `
    $description[**Kurallar

<a:ago:1182277758408212540> ! Küfür etmek yasak

<a:ago:1182277758408212540> ! Reklam yasak 

<a:ago:1182277758408212540> ! +18 Foto veya link atmak ve konuşma yasak 

<a:ago:1182277758408212540>  ! Caps Yazmak yasak # de geçerlidir

<a:ago:1182277758408212540>  ! Her türlü dine sövmek yasak

<a:ago:1182277758408212540> ! Kızlara Rahatsızlık vermek yasak ve erkekleri de

<a:ago:1182277758408212540> ! Kurucu ya baskı ve Küfür ve Bağırmak yasak 

<a:ago:1182277758408212540> ! Kanalı amaçsız kullanmak yasak

<a:ago:1182277758408212540> ! lütfen Kuralları Uyun 3 de ban yersiniz 

<a:ago:1182277758408212540> ! Reklam affetmiyoruz

<a:verified:1182041026790174720> Onay almıştı onay alınan kişi <@1141265487330811944>

$color[#ff0000] **]`
}, {
  name: "eğlence",
  aliases: [
    "EĞLENCE",
    "Eğlence",
  ],
  code: `
  $description[**__EĞLENCE__**

\`!hacker\`
**<a:ahile:1182302400925667358> Birini hackele mi**
  
 \`!zekaöç\`
**<a:havalidans:1182041022763642880> 1 den 100 gore öç**

\`!randomuser\`
**<a:havalidans:1182041022763642880> Random user ata**

\`!nuke\`
**<a:havalidans:1182041022763642880>> Nuke ata {Şaka}**

\`!bomba\`
**<a:havalidans:1182041022763642880> Bomba ata ama nuke daha iyi**

\`!yazıtura\`
**<a:havalidans:1182041022763642880> Yazı tura at**

\`!kazıkazan\`
**⛏️Kazı kaz 
  (Bu kod ekonomi kod değil)**

\`!zarat\`
**<a:havalidans:1182041022763642880> 1..6 kadar atasın**

\`!hediye\`
**<a:havalidans:1182041022763642880> Hediye?**

\`!renktahmin\`
**<a:havalidans:1182041022763642880> Renk tahmin et**

Tetikleyicisi
  **<a:__:1190780354487926825>**]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]$color[#ff0000]`

}, {
  name: "üye",
  aliases: [
    "ÜYE",
    "üye",
  ],
  code: `$color[#ff0000]$description[**__Üye__**
  
 \`!avatar\`
**<a:havalidans:1182041022763642880> Etiklendin kişinin avatarı ele etiket atmasan senin avatani ata**

\`!taşkağıtmakas\`
**<a:havalidans:1182041022763642880> Taş kağıt makas oynarsın**

\`!googleara\`
**<:openwrt2:1191060139277553748> Googleda ara**

\`!qrkod\`

 \`!kullanıcıbilgi\`
**<:user:1191060660906377348> Kullanıcı bilgilerini gösteri**

\`!kurucu veya !kurucun aynı\`
**<a:akral:1182291790431277056> Kurucum?**

\`!ppyap\`
**<a:havalidans:1182041022763642880> Pp yap**

\`!rolkimlik\`
**<a:havalidans:1182041022763642880> Rol Kimlik atıyor örnek
  #000000**
  
  \`!parlakyaz\`
**<a:havalidans:1182041022763642880> Parlak yazı yaz**

  \`!dmyaz\`
**<a:havalidans:1182041022763642880> Dm mesaj yaz**

  \`!sunucu\`
**<a:havalidans:1182041022763642880> Bot sunucu**

   \`!sunucubilgi\`
**<a:havalidans:1182041022763642880> Sunucu bilgisi**
 
   \`!sunuculogo\`
**<a:havalidans:1182041022763642880>Sunucu logo?**

   \`!ultraparlakyaz \`
**<a:havalidans:1182041022763642880> Ultra parlak yaz** 

   \`!e-okul-not\`
**<a:havalidans:1182041022763642880> Eğlence not**

   \`!büyükyaz\`
**<a:havalidans:1182041022763642880>  #-yaz**

 \`!yüksekrol\`
**<a:havalidans:1182041022763642880> Sunucunun en yüksek rol bilgi**

   \`!owner\`
**<a:akral:1182291790431277056> Sunucu sahibi kim?**

 \`!fotom \`
**<a:havalidans:1182041022763642880> avatarın fotoğrafnı atıyor**

   \`!descriptionyaz \`
**<a:havalidans:1182041022763642880> description yaz**

  \`!afiş\`
**<a:havalidans:1182041022763642880> Kullanıcı arka fotosu atıyor**

\`!bot\`
**<:iconscomments:1190777879961804850> Bot cevap veriyor 100/100**

  \`!takmaad\`
**<a:havalidans:1182041022763642880>Takma ad ata seninkini**

**Tetikleyicisi** **<a:__:1190780354487926825>**]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`}, {
  name: "saat",
  aliases: [
    "SAAT",
    "Saat",
  ],
  code: `$description[**__SAAT__**
\`!saniye-tut\`
  **<a:60saniye:1182041034130198618> !saniye-tut 2**

\`!dakika-tut\`
  **<a:60saniye:1182041034130198618> !dakika-tut 1**

\`!saat-tut\`
  **<a:60saniye:1182041034130198618> !saat-tut 1**]`}, {
  name: "ayarlama",
  code: `$description[**__AYARLAMA__**

\`!link-engel-aç\`
**<a:ayarlar:1182041028786671657> Link engeli aç**

\`!link-engel-kapat\`
**<a:ayarlar:1182041028786671657> Link engeli kapat**

\`!saas-aç\`
**<a:ayarlar:1182041028786671657> Sa As Açıyor selam gibile de aynı**

\`!saas-kapat\`
**<a:ayarlar:1182041028786671657> Sa As Kapatıyor**]
`
}]
