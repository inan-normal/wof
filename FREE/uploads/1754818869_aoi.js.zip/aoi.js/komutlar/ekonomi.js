module.exports = [
  {
    name: "ekonomi",
    code: `
    $title[**__EKONOMİ MENÜSÜ__**]
    $description[ <a:acoolclap:1182291015596519466> **\`$cüzdan\` = Parayını Gör**
     
     <a:acoolclap:1182291015596519466> **\`$günlük\` = 10000 Al

    <a:acoolclap:1182291015596519466> **\`$cf\` = Bakımda..
    
    <a:acoolclap:1182291015596519466> **\`$dilen\` = Dilenci Olmak İstemisin**]

    $footer[Ekonomi Menüsü]`
  },{
    name: "cüzdan",
      code: `
      $title[**__CÜZDAN MENÜSÜ__**]
      $description[**\`Para\` = $getGlobalUserVar[para]**]

      $footer[Cüzdan Menüsü]`
  },{
    name:"günlük",
    code:`
    $username Günlük Ödülün Olarak 1000 Para Hesabına Eklendi
    $setGlobalUserVar[para;$sum[$getGlobalUserVar[para;$authorID];10000];$authorID]

    $globalCooldown[12h;
    Bu komutu kullanabilmek için **%hour% Saat %min% Dakika** kadar beklemelisin] `
  },{
    name: "dilen",
    code: `  $setGlobalUserVar[para;$sum[$getGlobalUserVar[para;$authorID];$random[60;800]];$authorID]

  **<@$authorID>, para dilendin ve sana toplam $random[60;800] 💵 para verdile.**
    ` }]
