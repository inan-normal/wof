module.exports = [
  {
    name: "link-engel-aç",
    code: `
🔗 **Artık bu sunucuda kimse link paylaşamaz!**  
👑 Yalnızca yöneticiler paylaşabilir.

$setGuildVar[linkengel;açık]
$onlyClientPerms[administrator;❌ Botun yönetici yetkisi yok.]
$onlyPerms[administrator;🚫 Bu komutu kullanmak için \`YÖNETİCİ\` olmalısın.]
    `
  },
  {
    name: "link-engel-kapat",
    code: `
🔓 **Artık herkes link paylaşabilir.**

$resetGuildVar[linkengel]
$onlyClientPerms[administrator;❌ Botun yönetici yetkisi yok.]
$onlyPerms[administrator;🚫 Bu komutu kullanmak için \`YÖNETİCİ\` olmalısın.]
    `
  },
  {
    name: "$alwaysExecute",
    code: `
🧹 $deleteIn[7s]

🚫 <@!$authorID> Bu sunucuda link paylaşmak yasaktır!

$suppressErrors
$deleteCommand
$suppressErrors

$onlyIf[$checkContains[$message;https,http;://;.com;.gg;www.]!=false;]
$onlyIf[$hasPerms[$guildID;$authorID;administrator]!=true;]
$suppressErrors
$onlyIf[$getGuildVar[linkengel]!=kapalı;]
    `
  },
  {
    name: "saas-aç",
    code: `
💬 $reply  
✅ Selam verildiğinde artık otomatik cevap vereceğim.

$setGuildVar[saas;açık]
$onlyIf[$getGuildVar[saas]!=açık;⚠️ Bu sunucuda SaAs sistemi zaten açık.]
$onlyPerms[administrator;🚫 Bu komutu kullanmak için \`YÖNETİCİ\` iznine sahip olmalısın.]
    `
  },
  {
    name: "saas-kapat",
    code: `
💬 $reply  
❌ Selam verildiğinde artık cevap vermeyeceğim.

$setGuildVar[saas;kapalı]
$onlyIf[$getGuildVar[saas]!=kapalı;⚠️ Bu sunucuda SaAs sistemi zaten kapalı.]
$onlyPerms[administrator;🚫 Bu komutu kullanmak için \`YÖNETİCİ\` iznine sahip olmalısın.]
    `
  },
  {
    name: "sa",
    aliases: [
      "selam","selamın aleyküm","selamün aleyküm","selamın aleykum","selamün aleykum",
      "selamin aleykum","selamun aleykum","Selam","Selamın Aleyküm","Selamün aleyküm",
      "Selamın aleykum","Selamün aleykum","Selamin aleykum","Selamun aleykum",
      "Selamın aleyküm","Sa","Sea","sea","sA","SA"
    ],
    $if: "old",
    nonPrefixed: true,
    code: `
$if[$getGuildVar[saas]!=kapalı]
👋 Aleyküm selam <@$authorID>, hoş geldin!
$endif
    `
  }
]