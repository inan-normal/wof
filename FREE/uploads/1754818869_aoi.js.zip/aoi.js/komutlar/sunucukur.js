const kurucuRolRenk = '#ffff00';
const adminRolRenk = '#ff0000';
const üyeRolRenk = '#0020ff';
const botRolRenk = '#00b1ff';

module.exports = [{
  name: "sunucukur",
  code: `
$createRole[$guildID;🤖 Bot;${botRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;👤 Üye;${üyeRolRenk};1;;true;;false;false;Rol oluşturuldu!;]
$createRole[$guildID;⚙️ Admin;${adminRolRenk};1;;true;;true;false;Rol oluşturuldu!;]
$createRole[$guildID;🎩 Yetkili;${adminRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;🎩 Üst Yetkili;${adminRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;👑 Kurucu;${kurucuRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]
$createRole[$guildID;👑 Has Kurucu;${kurucuRolRenk};1;;true;;true;false;Rol oluşturuldu!;administrator]

$modifyChannelPerms[$get[2];$guildID;-sendmessages]

$modifyChannelPerms[$get[1];$guildID;-sendmessages]

  $createChannel[$guildID;╰┈➤《🎮》Cortex Bahis;Text;false;$get[4]]
  $createChannel[$guildID;├┈➤《🎮》Owo Bahis;Text;false;$get[4]]
  $createChannel[$guildID;╭┈➤《🎮》Ekonomi;Text;false;$get[4]]

$createChannel[$guildID;╰┈➤《🎮》Ekonomi;Text;false;$get[3]]
$let[sohbetKanalı;$createChannel[$guildID;╭┈➤《💭》sohbet;Text;true;$get[3]]]


$createChannel[$guildID;╰┈➤《🎫》ticket;Text;false;$get[2]]
$createChannel[$guildID;├┈➤《📢》duyuru;Text;false;$get[2]]
$let[kural;$createChannel[$guildID;╭┈➤《📕》kurallar;Text;true;$get[2]]]

$let[hgbb;$createChannel[$guildID;╭┈➤《🙋》gelen-giden;Text;true;$get[1]]]

$let[4;$createChannel[$guildID;∆ EKONOMI ODALARI;Category;true]]
$let[3;$createChannel[$guildID;∆ GENEL ODALAR;Category;true]]
$let[2;$createChannel[$guildID;∆ ÖNEMLİ;Category;true]]
$let[1;$createChannel[$guildID;∆ HOŞGELDİN;Category;true]]

$deleteRoles[$joinSplitText[;]]$textSplit[$guildRoles[$guildID;id;,];,]
$deleteChannels[$joinSplitText[;]]$textSplit[$guildChannels[$guildID;id;,];,]
$onlyClientPerms[managechannels;Bu işlemi gerçekleştirmem için Kanalları Yönet iznim olması gerekiyor.]
+eval $onlyIf[$rolePosition[$userHighestRole[$clientID;$guildID]]<=$rolePosition[$guildHighestRole];Lütfen benim rolümu en üste taşı yoksa rol silemem hepsini]
$onlyForIDs[$guildOwnerID;Bu komutu sadece sunucu sahibi kullanabilir!]`}]
