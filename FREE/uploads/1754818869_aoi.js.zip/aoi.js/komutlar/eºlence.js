const embedRenk = '#010101';
    module.exports = [{
    name: "taşkağıtmakas",
    code: `
  $description[**Bir tane butona basarak oyna**]
  
  $addButton[1;Taş;success;taş;false;🪨]
  $addButton[2;Kağıt;success;kağıt;false;✂️]
  $addButton[3;Makas;success;makas;false;🪨]
  $onlyClientPerms[administrator;Yetkim Yok Malesef]
  `
  },{
  
      name: "taş",
      type: "interaction",
      prototype: "button",
      code: `  $randomText[Ben kağıt;Ben Makas;AA aynı taş]`},{
  
    name: "kağıt",
      type: "interaction",
      prototype: "button",
      code:`$randomText[Ben Makas;ben Taş;aa Aynı kağıt]`},{
  
    name: "makas",
      type: "interaction",
      prototype: "button",
    code:`$randomText[ben Kağıt;ben taş;aa Aynı Makas]`},{
  
    name: "bot",
    code:`Ne diycemi bilmiyorum beni etiketle`},{
    
    name: "owner",
      code:`**Bu Mükemmel Sunucu Sahibi <@$guildOwnerID> Daha fazla bilgi için !sunucubilgi yazmanız yeteri **
  `},{
  
    name: "afiş",
    code:`$description[**Kullanıcı Afiş**]
    $image[$userBanner[$mentioned[1]]]
    
    $footer[arka foto varsa görebilirsiniz yoksa yok]`
      
  
  
  },{
    name: "yüksekrol",
      code: `$description[**__Başarılı şekilde Çalıştı__**
  
      **En Yüksek Rol İsmi:**\`$guildHighestRole[$guildID;name]\`
  
      **En Yüksek Rol ID:**\`$guildHighestRole[$guildID]\`
  
      **En Yüksek Rol Rengi:**\`$getRoleColor[$guildHighestRole[$guildID]]\`]
  
      $footer[Sunucun en yüksek rolü]`
  },{
    name: "kullanıcıbilgi",
    code: `
$title[Kullanıcı Bilgi] 
$description[
**Kullanıcı:**<@$mentioned[1]>
**Kullanıcı Takmad:**🏷️ $userNickname[$guildID;$authorID;true]
**Kullanıcı ID:**🆔 $mentioned[1]
**Kullanıcı Durum**$replaceText[$replaceText[$userStatus[$guildID;$authorID];online;🟢 Çevrimiçi];offline;🔴 Çevrimdışı]

**Hesap Oluşturma Tarihi:**📅$replaceText[$replaceText[$replaceText[$creationDate[$mentioned[1];date];AM;];PM;];,;:]

**Rolleri:🏷️**$replaceText[$userRoles[$mentioned[1];$guildID;mention;];@everyone;]
**En Yüksek Rolü:**⏫<@&$userHighestRole[$mentioned[1]]>
**En Aşağı Rolü:**⏬<@&$userLowestRole[$mentioned[1]]>

**Botmu:**$replaceText[$replaceText[$isBot[$mentioned[1]];false;👤 Bu Bir İnsan];true;👾 Bu Bir Bot]
`
},{
name: "qrkod",
code: `
$author[$memberDisplayName[$guildID;$authorID];$userAvatar]
$image[https://elixirapi.xyz/qrOlustur?format=jpg&bosluk=10&boyut=250x250&metin=$uri[$message]]
$color[${embedRenk}]
$addTimestamp
`
},{
name: "rolkimlik",
code: `$description[**__ROL RENK KİMLİK__**

**EN YÜKSEK ROLÜN RENK KİMLİK

$userRoleColor[$authorID;$guildID]**]
$footer[Bu Komutu $username kullandı]


`},{
    name:"ppyap",
  code:
     `$image[https://dynamic.brandcrowd.com/asset/logo/f802ad87-f5ae-491f-9a02-89ee701b588f/logo?v=4&text=$message]
 `
  },{
  name: "sunuculogo",
  code: `
  $description[**__SUNUCU SİMGE__**


  $image[$guildIcon[$guildID;4096;true;webp]]

$footer[Not:Sunucu simgesi yoksa atmaz]]
 $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin] `
    },{
  name:"dmyaz",
  code:`
  $dm[$mentioned[1]]
** $noMentionMessage **
$deletecommand
$suppressErrors
$onlyClientPerms[administrator;Yetkim Yok Malesef]`

},{
  name:"hacker",
  code:`$description[**$username[$mentioned[1]] Hackleniyor Aşağıda sonuç

Sahte Bilgileridi!!

E Posta
$randomText[dicord@gmail.com;monsterwolf@gmail.com;tiktok@gmail.com;porneposta@gmail.com;replit@gmail.com;hayattan@gmail.com;oyuncu@gmail.com]

Şifre
$random[10000000;20000000]

İp Adresi 
$random[28299;193902]

İsim
$randomText[Mahmut; Zeynep; Ümit; Selahattin;Osman;Enes;İsmail;Ali; Muhammed;Yasin;Kaptan]

Soyadı
$randomText[...; Bulunamadı;İnt hatası; Elektrik Hatası; Disord bilgi hatası]

Yaş
$random[10;40]

Adres İl
$randomText[İstanbul;Iğdır;Adana;Mersin;Konya;Osmaniye]

Adres İlçe
$randomText[Esenyurt;Kadıköy]

Discord ID
$mentioned[1]

Token 
Bulunamadı**]
$color[#ff0000]`
},{
  name:"zekaöç",
  code:`
$description[

IQ Seviyeni Ölçtüm Ve Aldığım Sonuçla Aşşağıda

**__Zeka Seviyen__** : $randomText[10;20;50;60;70;80;100]

$footer[$username]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
},{


  name:"renktahmin",
  code:`**Renk Seç 5 Saniye** $editIn[5s;Seçtim  ve Renk** $randomText[🟦;🟥;🟩;🟧]]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`

},{


  name:"kimsin",
  code:`$description[1;**__Ben Botum ve inandım din İslam__**]
$footer[1;$username Kullandı]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
    },{

  name: "saniye-tut",
  code:`
  **Tutuyorum**
  $editIn[$messages;**Bitti $message saniye**]
  $onlyIf[$message[2]<=50013;Dostum en fazla 50013 saniye tutabilirim
  $onlyIf[$message[1]>=5;Minimum 5!]
  $onlyIf[$isNumber[$message[1]]!=false;Sayı girmelisin]
  $suppressErrors[Hata]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
},{


  name: "dakika-tut",
  code:`

  **Tutuyorum**
  $editIn[$messagem;**Bitti $message dakika**]
  $onlyIf[$message[1]<=60;Dostum en fazla 60 dakika tutabilirim
  $onlyIf[$isNumber[$message[1]]!=false;Sayı girmelisin]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`},{


  name: "saat-tut",
  code:`
  **Tutuyorum**
  $editIn[$messageh;**Bitti $messages saat**]
  $onlyIf[$message[1]<=24;Dostum en fazla 24 saat tutabilirim
  $onlyIf[$isNumber[$message[1]]!=false;Sayı girmelisin]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`},{


 name: "kazıkazan",
 code:`
$description[kazı kazarak $randomText[100;200;300;400;500;600;700;800;900;1000 tl kazandın!]]
$title[Kazı Kazan] bu 
$footer[$username kullandı]
$color[FF0000]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]` },{


  name:"e-okul-not",
  code:`
$description[**🏫 E okul notları

📏 Matematik:$randomText[10;20;62;31;34;12;100;88;99;54;62;31;34]

🏛️ İnkılap/Sosyal:$randomText[20;40;35;23;12;100;88;99;54;62;31;34]

🎓 edebiyat/Türkçe:$randomText[40;29;40;35;23;12;1;99;54;62;31;34;100;88]

⛹️ Spor/beden:$randomText[88;99;54;62;31;34;10;20;40;35;23;12;100;-100]

📔 İngilizce:$randomText[20;40;35;23;12;100;1/;88;99;54;62;31;34]

⚛️ Fen/Fizik:$randomText[40;35;3;12;100;88;99;54;62;31;34]

🧪 Kimya/Biyoloji:$randomText[10;20;40;35;23;12;100;88;99;54;62;31;34]

🎞️ Resim:$randomText[100;88;99;54;0;40;35;23;12;62;31;34]

🎧 Müzik:$randomText[0;40;35;23;12;100;88;99;54]**
$footer[5...10 sınava kadar not bilgisi]]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
    },{
  name:"büyükyaz",
  code:`# $message
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`

    },{
  name:"bomba",
  code:`BOMBA!!! $editIn[5s;\`BOMBA= $randomText[Sonuç=☠️  200 Ölür 🏚️ 100 Ev Yok edildi 🗣️ Başbakan Tahtadan indir;☠️  100 Ölür 🏚️ 200 Ev Yok edildi 🗣️ Başkan Tahtadan indir;☠️  900 Ölür 🏚️ 290 Ev Yok edildi 🗣️ Başkan Tahtadan indir]\`]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
    },{

  name:"takmaad",
code:`$userNickname[$guildID;$authorID;true]
$onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
  },{


  },{
  name:"sayı-tahmin",
  code:`$description[1; Tuttuğum sayı $random[1;100] ve sen tahmin ettiğin sayı $message[1]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
    },{

  name: "sunucubilgi",
  code: `$description[**__Sunucu bilgisi__**

**<a:akral:1182291790431277056>  Sunucu Adı:$guildName**
**<a:akral:1182291790431277056>  Sunucu Sahibi:$username[$guildOwnerID]**
**🆔 Sunucu ID**:**$guildID**

**<a:ayarlar:1182041028786671657>  toplam kanal sayısı**:**$channelCount[$guildID;all]**
**<a:ayarlar:1182041028786671657>  toplam Yazı kanal sayısı**:**$channelCount[$guildID;Text]**
**<a:ayarlar:1182041028786671657>  toplam Ses kanal sayısı**:**$channelCount[$guildID;Voice]**

**<:user:1191060660906377348> Sunucu rol sayısı**:**$roleCount**
**<:user:1191060660906377348> Sunucu üye sayısı**:**$membersCount**
**<a:acoolclap:1182291015596519466> Sunucu emoji sayısı**:**$emojiCount[$guildID]**

**<a:acoolclap:1182291015596519466> Rol Sıralaması**
**<:nyukari:1192768362237927454> $guildHighestRole[$guildID;name]**
**<:nasagi:1192768302087426058>  $guildLowestRole[$guildID;name]**

**<a:boost:1182041040547483648> Boost sayısı**:**$guildBoostCount[$guildID]**
**<a:instaflip:1182041007873867946> Sunucu Simgesi:**
$suppressErrors[🔴| Bir hata oluştu]
$image[$guildIcon[$guildID;4096;true;webp]]]
$footer[!sunucukur|!sunuculogo|!yetkili|!ayarlama]`
    },{
  name: "googleara",
  code:`
  $title[GOOGLE ARAMA]
  $description[**Bunu buldum** 
[İstediniz Sonuç](https://www.google.com/search?q=$message[1]$message[2]$message[3]$message[4]$message[5]$message[6]$message[7]$message[8])]

  $image[https://cdn1.ntv.com.tr/gorsel/x4yYn8UPYEmqdxRTh7IsLQ.jpg?width=1200&height=675&mode=crop&scale=both&v=1695799763153&meta=rectangle]
  $footer[Aramak istediniz kelime $message!]
  $suppressErrors[🔴| Bir hata oluştu]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]` },{


name: "avatar",
code: `$description[$image[$userAvatar[$findMember[$message]]]
      $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
  },{


  name:"fotom",
  code:`
$image[$userAvatar]

$onlyIf[$checkContains[$channelType;text;news]==true;]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]
  $footer[!kullanıcıbilgi|!avatar|!üye!eğlence]`

    },{
name: "zarat",
  code:`
**Zar mi attın hmm dönüyor ve ve **$editIn[2s;$randomText[1 Berbat;2 Berbat;3 yani;4 iyi;5 Dostum iyi sin;6 Oha]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`  },{



  name: "nuke",
  code:`
$title[Nuke attı]
$description[☠️  200+ Ölür 
🏚️ 250+ Ev Yok edildiği]
$image[https://cdn.discordapp.com/attachments/1098849038360662058/1155601419886411856/Screenshot_20230924-2326232.png]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`  },{



  name:"hediye",
    code:`$title[Hediyen Hazır! 📦]
  $description[
  **Hediyen:**$randomText[🔫;🪃;🏹;📍;🪙;💰;📚;🔦;📷;👕;🍩;🛹;🛼;🚲;🛴;🚁;⛴️;**Hediyen Yok:(**]]
    $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
},{


      name: "randomuser",
      code: `
      $reply
      $deletecommand <@$randomUserID>
      $onlyClientPerms[administrator;Yetkim Yok Malesef]
      $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
        },{



      name: "parlakyaz",
      code: `$deletecommand **$message**
      $onlyClientPerms[administrator;Yetkim Yok Malesef]
        $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
        },{


  },{
      name: "ultraparlakyaz",
      code: `
      $reply
      $deletecommand ***$message**
      $onlyClientPerms[administrator;Yetkim Yok Malesef]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
        },{


    name: "yazıtura",
    code: `$deletecommand $randomText[**Yazı geldi sen ne seçtin**;Tura geldi sen ne seçtin?;Para dik durdu!]
    $onlyClientPerms[administrator;Yetkim Yok Malesef]
  $onlyIf[$getGlobalUserVar[kara]!=alınmış;Karalistedesin]`
}]