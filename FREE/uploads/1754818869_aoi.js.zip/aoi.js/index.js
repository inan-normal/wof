const { AoiClient } = require("aoi.js");

const client = new AoiClient({
  token: "MTMzNTMyNTA1OTEzNjM1NjQ1Mw.Gj-GuR.RMFDuE1fwyRVC_CNRrKXLujHSRJW1Tp4lfhcdU",
  prefix: ['!',],
  intents: ["MessageContent", "Guilds", "GuildMessages"],
  events: ["onMessage", "onInteractionCreate"],
  database: {
    type: "aoi.db",
    db: require("@akarui/aoi.db"),
    tables: ["main"],
    path: "./database/",
    extraOptions: {
      dbType: "KeyValue",
    },
  },
});

client.loadCommands("./komutlar/", true);

client.command({
  name: "yeniler",
  code: `**Yenilendi $updateCommands**`
})

client.variables({
  para: "0",
  kara: "kapalı",
  saas: "kapalı",
  linkengel: "kapalı"
})

client.status({
  name: "!yardım",
  type: "PLAYING",
  time: 5,
});
