import tkinter as tk
from tkinter import ttk

class HesapMakinesi:
    def __init__(self, master):
        self.master = master
        master.title("Modern Hesap Makinesi")

        # Stil oluşturma
        self.style = ttk.Style()
        self.style.theme_use("clam") # Modern bir tema kullan
        self.style.configure("TButton", padding=10, font=("Helvetica", 12), foreground="#333", background="#eee")
        self.style.configure("TEntry", font=("Helvetica", 14), foreground="#333")

        # Ekran
        self.ekran = tk.StringVar()
        self.ekran.set("0")
        self.ekran_girisi = ttk.Entry(master, textvariable=self.ekran, state="readonly", width=20, justify="right")
        self.ekran_girisi.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        # Düğmeler
        self.dugumler = {
            "C": (1, 0),
            "CE": (1, 1),
            "/": (1, 2),
            "*": (1, 3),
            "7": (2, 0),
            "8": (2, 1),
            "9": (2, 2),
            "-": (2, 3),
            "4": (3, 0),
            "5": (3, 1),
            "6": (3, 2),
            "+": (3, 3),
            "1": (4, 0),
            "2": (4, 1),
            "3": (4, 2),
            "=": (4, 3),
            "0": (5, 0),
            ".": (5, 1),
            "(": (5, 2),
            ")": (5, 3)
        }

        for metin, konum in self.dugumler.items():
            dugme = ttk.Button(master, text=metin, command=lambda metin=metin: self.dugme_tikla(metin))
            dugme.grid(row=konum[0], column=konum[1], padx=5, pady=5)

        # İşlem
        self.islem = ""

    def dugme_tikla(self, metin):
        if metin == "=":
            try:
                sonuc = eval(self.ekran.get())
                self.ekran.set(sonuc)
            except:
                self.ekran.set("Hata")
        elif metin == "C":
            self.ekran.set("0")
        elif metin == "CE":
            self.ekran.set(self.ekran.get()[:-1])
        else:
            if self.ekran.get() == "0":
                self.ekran.set(metin)
            else:
                self.ekran.set(self.ekran.get() + metin)

root = tk.Tk()
hesap_makinesi = HesapMakinesi(root)
root.mainloop()