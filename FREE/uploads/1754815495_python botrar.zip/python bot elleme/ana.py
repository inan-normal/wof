import discord
from discord.ext import commands
import asyncio
import typing
from datetime import timedelta
import discord
from discord.ext import commands
from discord.ext.commands import bot
import asyncio
import time
import random
import discord
from discord.ext import commands, tasks
from discord.utils import get

intents = discord.Intents.all()

class MyBot(commands.Bot):
    def __init__(self, *args, **kwargs):
        super().__init__(command_prefix='a!', intents=intents, *args, **kwargs)

bot = MyBot()

@bot.event
async def on_ready():
    print(f'Bot {bot.user} Olarak Giris Yaptı!')
    print('DİSCORD BOT AÇIK!')

@bot.event
async def on_command_error(ctx, error):
    print(f'Hata: {error}')

# İMPORT/HATA/AÇILIŞ FALAN BİTTİ KOMUTLAR!

@bot.command(name='yardım',)
async def yardım(ctx):
    await ctx.send('Sana Nasıl Yardımcı Olurum? (a!komutlar)')

@bot.command(pass_context=True)
async def ping(ctx):
    await ctx.message.delete()
    t1 = time.perf_counter()
    t2 = time.perf_counter()
    await ctx.send('Ping:'.format(round((t2-t1)*1000)))

@bot.command()
@commands.has_guild_permissions(ban_members=True)
async def clearall(ctx, amount: int):
    await ctx.channel.purge(limit=amount)
    await ctx.send('**Mesajlar Silindi**')

@bot.command(pass_context=True)
async def komutlar(ctx):
    await ctx.message.delete()
   

    embed = discord.Embed(
        colour = discord.Colour.blue()
    )

    embed.set_author(name='Komutlar')
    embed.add_field(name='clearall', value='Tüm Mesajları Siliyor', inline=False)
    embed.add_field(name='ping', value='Botun Pingi', inline=False)
    embed.add_field(name='yardım', value='Yardım Mesajı Atıyor', inline=False)
    embed.add_field(name='bilgim', value='Discord Bilgisi Verir', inline=False)
    embed.add_field(name='ban', value='Sunucudan Yasakla', inline=False)
    embed.add_field(name='kick', value='Sunucudan At', inline=False)
    embed.add_field(name='parlakyaz', value='Kullanıcının Yazısını Parlak Yapıyor', inline=False)
    embed.add_field(name='büyükyaz', value='Kullanıcının Yazısını Büyük Yapıyor', inline=False)
    embed.add_field(name='ask', value='Aşk Ol', inline=False)
    await ctx.send(embed=embed)

@bot.command(pass_context=True)
async def bilgim(ctx, member: discord.Member=None):
    await ctx.message.delete()
    member = ctx.message.author
    channel = ctx.message.channel
    if member is None:
        pass
    else:
        await channel.send("```AD: {}```".format(member.name) + "\n```ID: {}```".format(member.id) + "\n```DURUM: {}```".format(member.status) + "\n```ROL: {}```".format(member.top_role) + "\n```SUNUCU KATILMA TARİH:{}```".format(member.joined_at))

@bot.command()
async def parlakyaz(ctx, *, name):
    await ctx.send(f"**{name}**")

@bot.command()
async def büyükyaz(ctx, *, name):
    await ctx.send(f"# {name}")




@bot.command()
async def ask(mesaj, member: discord.Member):
    emb = discord.Embed(description= "**" + mesaj.author.name +  "**Sana Aşk Oldu {0.mention}" .format(member), color=000000)
    emb.set_image(url="https://th.bing.com/th?id=OIP.ohGATjoGEUvHZ9l3xgOOGgAAAA&w=292&h=213&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2")
    await mesaj.send(embed=emb)


        # KOMUT BİTTİ


#izinler
@bot.command()
@commands.has_guild_permissions(ban_members=True)
async def kick(ctx, member: discord.Member, *args, reason="yok"):
    await member.kick(reason=reason)
    await ctx.send('**Sunucudan Attım (Ele Kullanıcı Kick Yemiyorsa Hata Vardı)**')

@bot.command()
@commands.has_guild_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *args, reason="yok"):
    await member.ban(reason=reason)
    await ctx.send('**Ban Attım (Ele Kullanıcı Ban Yemedise Hata Var Demektir Tekrar Dene)**')

@ban.error
async def ban_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("**Kullanıcı Etiketle**")

@kick.error
async def kick_error(ctx, error):
    if isinstance(error, commands.BotMissingPermissions):
        await ctx.send("**Dostum Yetkim Yok**")

@clearall.error
async def clearall_error(ctx, error):
    if isinstance(error, commands.BotMissingPermissions):
        await ctx.send("**Dostum Yetkim Yok**")

@kick.error
async def kick_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("**Kullanıcı Etiketle**")

@parlakyaz.error
async def parlakyaz_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("**Selam Lütfen Parlak Yaz Komutunu Düzgün Kullan a!parlakyaz (örnek)**")

@büyükyaz.error
async def büyükyaz_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("**Selam Lütfen Büyük Yaz Komutunu Düzgün Kullan a!büyükyaz (örnek)**")

@ask.error
async def ask_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("**Aşksın Anladık Ama Hatalı Girdin (a!ask <@Kullanıcı>)**")



# BOT TOKENI

bot.run('MTI0MjUzNDEwMTIzNjMxODI0OQ.GUhIjq.jmAyVsheFiego8IdAp77nivU1rwgKQQsTN4qHk')