function guncelleZaman() {
  const simdikiZaman = new Date();
  const saatler = simdikiZaman.getHours().toString().padStart(2, '0');
  const dakikalar = simdikiZaman.getMinutes().toString().padStart(2, '0');
  const saniyeler = simdikiZaman.getSeconds().toString().padStart(2, '0');
  const zamanMetni = `${saatler}:${dakikalar}:${saniyeler}`;

  const gun = simdikiZaman.getDate();
  const ay = simdikiZaman.getMonth() + 1; // Ay 0'dan başlar, bu yüzden 1 ekliyoruz
  const yil = simdikiZaman.getFullYear();
  const tarihMetni = `${gun}/${ay}/${yil}`;

  document.getElementById("zaman").textContent = zamanMetni;
  document.getElementById("tarih").textContent = tarihMetni;
}

setInterval(guncelleZaman, 1000); // Saati her saniye güncelle